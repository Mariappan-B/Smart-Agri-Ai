document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("agri-form");
    const btnLocation = document.getElementById("btn-location");
    const btnPredict = document.getElementById("btn-predict");
    const locationStatus = document.getElementById("location-status");
    
    const inputLat = document.getElementById("lat");
    const inputLon = document.getElementById("lon");
    
    const loadingSection = document.getElementById("loading");
    const resultsSection = document.getElementById("results");
    const btnReset = document.getElementById("btn-reset");

    // Fetch Location
    btnLocation.addEventListener("click", () => {
        if ("geolocation" in navigator) {
            locationStatus.textContent = "Fetching location...";
            locationStatus.className = "status-msg";
            
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    inputLat.value = position.coords.latitude;
                    inputLon.value = position.coords.longitude;
                    locationStatus.textContent = "Location secured successfully!";
                    locationStatus.className = "status-msg success";
                    btnPredict.disabled = false;
                },
                (error) => {
                    console.error("Error getting location:", error);
                    locationStatus.textContent = "Failed to get location. Please allow location access.";
                    locationStatus.className = "status-msg error";
                    // For demo purposes, we will still allow prediction with dummy coordinates
                    inputLat.value = 20.5937; // Center of India
                    inputLon.value = 78.9629;
                    btnPredict.disabled = false;
                }
            );
        } else {
            locationStatus.textContent = "Geolocation is not supported by your browser.";
            locationStatus.className = "status-msg error";
        }
    });

    // Handle Form Submit
    form.addEventListener("submit", async (e) => {
        e.preventDefault();
        
        if(!inputLat.value || !inputLon.value) {
            alert("Please get your location first.");
            return;
        }

        const payload = {
            soil_answers: {
                color: document.getElementById("soil-color").value,
                texture: document.getElementById("soil-texture").value,
                water_retention: document.getElementById("water-retention").value
            },
            location: {
                lat: parseFloat(inputLat.value),
                lon: parseFloat(inputLon.value)
            }
        };

        // Show loading
        form.classList.add("hidden");
        loadingSection.classList.remove("hidden");

        try {
            // Adjust the URL if deploying remotely.
            const response = await fetch("http://localhost:8000/predict", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(payload)
            });

            if (!response.ok) {
                throw new Error("Failed to get prediction from server.");
            }

            const data = await response.json();
            
            displayResults(data);

        } catch (error) {
            console.error(error);
            alert("Error predicting crop. Make sure the backend server is running.");
            loadingSection.classList.add("hidden");
            form.classList.remove("hidden");
        }
    });

    function displayResults(data) {
        loadingSection.classList.add("hidden");
        resultsSection.classList.remove("hidden");

        // Best Crop
        document.getElementById("best-crop").textContent = data.best_crop;

        // Profitable Alternatives
        const profitList = document.getElementById("profitable-crops");
        profitList.innerHTML = "";
        data.top_profitable_crops.forEach((crop, index) => {
            const li = document.createElement("li");
            li.innerHTML = `<span>#${index + 1} ${crop}</span> <span style="color:var(--primary)"><i class="fas fa-arrow-up"></i> High Profit</span>`;
            profitList.appendChild(li);
        });

        // Env Stats
        document.getElementById("res-ph").textContent = data.estimated_soil.pH.toFixed(1);
        document.getElementById("res-npk").textContent = `${data.estimated_soil.N}/${data.estimated_soil.P}/${data.estimated_soil.K}`;
        document.getElementById("res-temp").textContent = `${data.weather.temp.toFixed(1)}°C`;
        document.getElementById("res-hum").textContent = `${data.weather.humidity.toFixed(1)}%`;
    }

    // Reset
    btnReset.addEventListener("click", () => {
        resultsSection.classList.add("hidden");
        form.reset();
        inputLat.value = "";
        inputLon.value = "";
        locationStatus.textContent = "";
        btnPredict.disabled = true;
        form.classList.remove("hidden");
    });
});
